package com.example.pr19_2

data class Tic(val number: String, val type: String)