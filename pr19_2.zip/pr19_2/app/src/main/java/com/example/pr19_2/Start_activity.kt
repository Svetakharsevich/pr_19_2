package com.example.pr19_2

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class Start_activity : AppCompatActivity() {
    private lateinit var login: EditText
    private lateinit var parol: EditText
    private lateinit var ex: Button
    private lateinit var sh:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)
        login = findViewById(R.id.login)
        parol = findViewById(R.id.parol)
        ex = findViewById(R.id.button)
        sh=getSharedPreferences("login", Context.MODE_PRIVATE)
        var logins = sh.getString("login",null)
        var password=sh.getString("password",null)
        login.setText(logins)
        parol.setText(password)
        ex.setOnClickListener{
            if(login.text.toString().isEmpty()||parol.text.toString().isEmpty()){
                Toast.makeText(this,"Введите логин или пароль",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this,List_activity::class.java)
            startActivity(intent)
        }
    }
}