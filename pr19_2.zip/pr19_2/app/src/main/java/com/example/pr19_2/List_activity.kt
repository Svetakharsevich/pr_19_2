package com.example.pr19_2

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast

class List_activity : AppCompatActivity() {
    private lateinit var list:ListView
    lateinit var save:Button
    private lateinit var clear:Button
    private lateinit var numeric:EditText
    private lateinit var type:EditText
    private lateinit var adapter:ArrayAdapter<String>
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        list=findViewById(R.id.lists)
        save=findViewById(R.id.add)
        clear=findViewById(R.id.clear)
        numeric=findViewById(R.id.numeric)
        type=findViewById(R.id.type)
        save.setOnClickListener {
            if (numeric.text.toString().isEmpty() || type.text.toString().isEmpty()) {
                Toast.makeText(this, "Введите номер и тип билета", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val number = numeric.text.toString()
            val types = type.text.toString()
            val tic = JSONHelper.loadTickets(this)
            val tics = Tic(number, types)
            val upTic = tic.toMutableList()
            upTic.add(tics)
            JSONHelper.saveTickets(this, upTic)
            Toast.makeText(this, "Билет $number добавлен", Toast.LENGTH_SHORT).show()
            numeric.text=null
            type.text=null
            updateList()
            val input=getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            input.hideSoftInputFromWindow(save.
            windowToken,0)
            adapter=createTic()
            list.adapter=adapter
        }
        clear.setOnClickListener{
            JSONHelper.clearTickets(this)
            adapter.clear()
            adapter.notifyDataSetChanged()
            updateList()
        }

    }
    private fun createTic():ArrayAdapter<String>{
        val tice=JSONHelper.loadTickets(this)
        val ticData=tice.map{"${it.number}-${it.type}"}
        val adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,ticData)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        return adapter
    }
    private fun updateList(){
        val tick=JSONHelper.loadTickets(this)
        val ticsData=tick.map {"${it.number}-${it.type}"}
        val adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,ticsData)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        list.adapter=adapter
    }
}